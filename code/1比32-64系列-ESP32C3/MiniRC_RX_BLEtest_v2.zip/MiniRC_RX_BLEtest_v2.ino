#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
// #include <Servo.h>
// See the following for generating UUIDs:
// https://www.uuidgenerator.net/

#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

////////////// 控制码定义 ///////////////
//数字量，0代表开启，1关闭，与上位机保持一致，硬件设计为上拉驱动
String value_string="";

std::string car_front_light = "";
std::string car_back_light = "";
std::string car_left_light = "";
std::string car_right_light = "";

std::string car_park_back_go = "";
std::string car_trumpet = "";
std::string car_cut_off = "";
std::string car_wiper = "";
std::string car_break = "";

int car_speed = 0;//2 pwm 0 1
int car_direction = 0;//1 pwm 2
// int car_speed = 0;
// int car_direction_0_90 = 0;
///////////////////////////////////////////
////////////// 功能端口定义 ///////////////
//8,9,6暂未使用,8暂时为test pin
const int test_Pin = 8;//test pin

const int speed_Pin_p = 0;//pwm
const int speed_Pin_n = 1;//pwm
const int direction_Pin = 2;//pwm

const int direction_Pin_dp = 4;//pwm
const int direction_Pin_dn = 5;//pwm

const int front_light_Pin = 21;//digit
const int back_light_Pin = 20;//digit
const int left_light_Pin = 10;//digit
const int right_light_Pin = 7;//digit

const int trumpet_Pin = 3;//pwm

int trumpet_Pin_count = 0;
int trumpet_Pin_count_max = 70;
int trumpet_Pin_state = 0;

int left_light_Pin_count = 0;
int left_light_Pin_count_max = 20000;
int left_light_Pin_state = 0;

int light_trumpet_Pin_state = 0;

int right_light_Pin_count = 0;
int right_light_Pin_count_max = 20000;
int right_light_Pin_state = 0;

int cut_off_Pin_count = 0;
int cut_off_Pin_count_max = 20000;
int cut_off_Pin_state = 0;

int direction_Pin_count = 0;
int direction_Pin_count_max = 400;
int direction_count_rate=0;
///////////////////////////////////////////
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {   //当蓝牙连接时会执行该函数
      // Serial.println("蓝牙已连接");
      digitalWrite(front_light_Pin,1);
      for(int i=0;i<200;i++){
        digitalWrite(trumpet_Pin,1);
        delay(1);
        digitalWrite(trumpet_Pin,0);
        delay(1);
      }
      digitalWrite(front_light_Pin,0);
      digitalWrite(test_Pin,0);//test pin
    
    };

    void onDisconnect(BLEServer* pServer) {  //当蓝牙断开连接时会执行该函数
      // Serial.println("蓝牙已断开");
	  // deviceConnected = false;
      digitalWrite(front_light_Pin,1);
      for(int i=0;i<200;i++){
        digitalWrite(trumpet_Pin,1);
        delay(1);
        digitalWrite(trumpet_Pin,0);
        delay(1);
      }
      digitalWrite(front_light_Pin,0);
      digitalWrite(test_Pin,1);//test pin

      delay(500); // give the bluetooth stack the chance to get things ready
      pServer->startAdvertising(); // restart advertising

    }
};
class MyCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
      
      std::string value = pCharacteristic->getValue();
      // value_string = String(value.c_str(),value.length());
      // Serial.println(value_string);
      car_front_light = value.substr(0,1);
      car_back_light = value.substr(1,1);
      car_left_light = value.substr(2,1);
      car_right_light = value.substr(3,1);
      car_park_back_go = value.substr(4,1);
      car_trumpet = value.substr(5,1);
      car_cut_off = value.substr(6,1);
      car_wiper = value.substr(7,1);
      car_break = value.substr(8,1);
      car_speed = std::stoi(value.substr(9,3)) - 100;
      car_direction = std::stoi(value.substr(12,3)) - 280;

    }
};

void setup() {
  // Serial.begin(115200);
  pinMode(test_Pin, OUTPUT);
  digitalWrite(test_Pin,1);

  pinMode(speed_Pin_p, OUTPUT);
  pinMode(speed_Pin_n, OUTPUT);
  pinMode(direction_Pin, OUTPUT);
  pinMode(direction_Pin_dp, OUTPUT);
  pinMode(direction_Pin_dn, OUTPUT);
  pinMode(front_light_Pin, OUTPUT);
  pinMode(back_light_Pin, OUTPUT);
  pinMode(left_light_Pin, OUTPUT);
  pinMode(right_light_Pin, OUTPUT);
  pinMode(trumpet_Pin, OUTPUT);

  ledcSetup(0, 500, 8);
  ledcAttachPin(speed_Pin_p, 0);

  ledcSetup(1, 500, 8);
  ledcAttachPin(speed_Pin_n, 1);

  ledcSetup(2, 500, 8);
  ledcAttachPin(direction_Pin_dp, 2);

  ledcSetup(3, 500, 8);
  ledcAttachPin(direction_Pin_dn, 3);

  BLEDevice::init("MyESP32 RC CAR");
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  BLECharacteristic *pCharacteristic = pService->createCharacteristic(
                                         CHARACTERISTIC_UUID,
                                         BLECharacteristic::PROPERTY_READ |
                                         BLECharacteristic::PROPERTY_WRITE
                                       );

  pCharacteristic->setCallbacks(new MyCallbacks());

  pCharacteristic->setValue("Hello World");
  pService->start();

  BLEAdvertising *pAdvertising = pServer->getAdvertising();
  pAdvertising->start();
}
int clip(int value, int minValue, int maxValue) {
    if (value < minValue) {
        return minValue; // 如果 value 小于 minValue，则返回 minValue
    } else if (value > maxValue) {
        return maxValue; // 如果 value 大于 maxValue，则返回 maxValue
    } else {
        return value; // 否则返回原值
    }
}

void loop() {
////////////// 车辆进退 ///////////////
    // car_park_back_go = "3";
    if(car_park_back_go!="3"){
      if(car_park_back_go=="0"){
        ledcWrite(0, 0);
        ledcWrite(1, 0);
      }else if(car_park_back_go=="1" && car_break!="0"){
        ledcWrite(0, car_speed);
        ledcWrite(1, 0);
      }else if(car_park_back_go=="2" && car_break!="0"){
        ledcWrite(0, 0);
        ledcWrite(1, car_speed);
      }else{
        ledcWrite(0, 0);
        ledcWrite(1, 0);
      }
    }else{
      if(car_speed>155){
        ledcWrite(0, 0);
        ledcWrite(1, (car_speed-155)*2.55);        
      }else if(car_speed<140){
        ledcWrite(0, (-car_speed+140)*1.82);
        ledcWrite(1, 0);    
      }else{
        ledcWrite(0, 0);
        ledcWrite(1, 0);
      }


    }


////////////////////////////////////////////
////////////// 车辆方向 ///////////////
    //0.5ms~2.5ms in 0-180 = 0.025~0.125
    // direction_count_rate = direction_Pin_count_max*((car_direction+180)*0.00027778+0.025);
    direction_count_rate = direction_Pin_count_max*((car_direction+180)*0.00044778+0.035);
    if(direction_Pin_count<direction_count_rate){
      digitalWrite(direction_Pin,1);
    }else{
      digitalWrite(direction_Pin,0);
    }
    if(direction_Pin_count==direction_Pin_count_max){
      direction_Pin_count=0;
    }
    direction_Pin_count++;
    if(car_direction<-20){
      ledcWrite(2, (-car_direction)*1.41); // 255/180=1.41
      ledcWrite(3, 0);
    }else if (car_direction>20){
      ledcWrite(2, 0);
      ledcWrite(3, car_direction*1.41);
    }else{
      ledcWrite(2, 0);
      ledcWrite(3, 0);
    }
////////////////////////////////////////////
////////////////// 车辆灯光 ///////////////////
    if(car_front_light=="0"){
      digitalWrite(front_light_Pin,1);
    }else{
      digitalWrite(front_light_Pin,0);
    }
    if(car_back_light=="0"){
      digitalWrite(back_light_Pin,1);
    }else{
      digitalWrite(back_light_Pin,0);
    }
//左转向灯
    if(car_left_light=="0" && car_right_light!="0" && car_cut_off!="0"){
       if(left_light_Pin_count==left_light_Pin_count_max){
        left_light_Pin_count=0;
        if(left_light_Pin_state==0){
          digitalWrite(left_light_Pin,1);
          left_light_Pin_state = 1;
        }else{
          digitalWrite(left_light_Pin,0);
          left_light_Pin_state = 0;          
        }
        // }
        if(light_trumpet_Pin_state==0){
          digitalWrite(trumpet_Pin,1);
          light_trumpet_Pin_state=1;
        }else{
          digitalWrite(trumpet_Pin,0);
          light_trumpet_Pin_state=0;
        }
      }
      left_light_Pin_count++;
    }else{
      if(car_cut_off!="0"){
      digitalWrite(left_light_Pin,0);
      }
    }

//右转向灯
    if(car_right_light=="0" && car_left_light!="0" && car_cut_off!="0"){
       if(right_light_Pin_count==right_light_Pin_count_max){
        right_light_Pin_count=0;
        if(right_light_Pin_state==0){
          digitalWrite(right_light_Pin,1);
          right_light_Pin_state = 1;
        }else{
          digitalWrite(right_light_Pin,0);
          right_light_Pin_state = 0;          
        }
        // }
        if(light_trumpet_Pin_state==0){
          digitalWrite(trumpet_Pin,1);
          light_trumpet_Pin_state=1;
        }else{
          digitalWrite(trumpet_Pin,0);
          light_trumpet_Pin_state=0;
        }
      }
      right_light_Pin_count++;
    }else{
      if(car_cut_off!="0"){
      digitalWrite(right_light_Pin,0);
      }
    }

    if(car_cut_off=="0"){
        if(cut_off_Pin_count==cut_off_Pin_count_max){
        cut_off_Pin_count=0;
        if(cut_off_Pin_state==0){
          digitalWrite(left_light_Pin,1);
          digitalWrite(right_light_Pin,1);
          cut_off_Pin_state = 1;
        }else{
          digitalWrite(left_light_Pin,0);
          digitalWrite(right_light_Pin,0);
          cut_off_Pin_state = 0;          
        }
      }
      cut_off_Pin_count++;
    }
////////////////////////////////////////////
////////////////// 车辆喇叭 ///////////////////
    if(car_trumpet=="0"){
      digitalWrite(direction_Pin,0);
      if(trumpet_Pin_count==trumpet_Pin_count_max){
        trumpet_Pin_count=0;
        if(trumpet_Pin_state==0){
          digitalWrite(trumpet_Pin,1);
          trumpet_Pin_state = 1;
        }else{
          digitalWrite(trumpet_Pin,0);
          trumpet_Pin_state = 0;          
        }
        
      }
      trumpet_Pin_count++;
    }
    if(car_trumpet!="0" && car_left_light!="0" && car_right_light!="0"){
      digitalWrite(trumpet_Pin, 0);
      light_trumpet_Pin_state=0;
      trumpet_Pin_state = 0;  
    }
////////////////////////////////////////////
}

